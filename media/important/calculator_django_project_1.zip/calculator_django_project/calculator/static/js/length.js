let first = document.getElementById('para')
let last = document.getElementById('tara')
let sale = document.getElementById('konsa')
let sale1 = document.getElementById('vowala')
const fun = ()=>{
    if (sale.value == 1){
        if (sale1.value == 1){
            first.value = last.value
        }
        else if(sale1.value == 2){
            first.value = last.value*2.54
        }
        else if(sale1.value == 3){
            first.value = last.value/10
        }
        else if(sale1.value == 4){
            first.value = last.value*100
        }
        else if(sale1.value == 5){
            first.value = last.value*100000
        }
        else if(sale1.value == 6){
            first.value = last.value*30.48
        }
        else if(sale1.value == 7){
            first.value = last.value*91.44
        }
        else if(sale1.value == 8){
            first.value = last.value*160900
        }

        
    }
    else if(sale.value == 2){
        if (sale1.value == 1){
            first.value = last.value/2.54
        }
        else if(sale1.value == 2){
            first.value = last.value
        }  
        else if(sale1.value == 3){
            first.value = last.value/25.4
        }
        else if(sale1.value == 4){
            first.value = last.value/39.3701
        }
        else if(sale1.value == 5){
            first.value = last.value*39370
        }
        else if(sale1.value == 6){
            first.value = last.value*12
        }
        else if(sale1.value == 7){
            first.value = last.value*36
        }
        else if(sale1.value == 8){
            first.value = last.value*63360
        }
    }
    else if(sale.value == 3){
        if (sale1.value == 1){
            first.value = last.value*10
        }
        else if(sale1.value == 2){
            first.value = last.value/25.4
        }  
        else if(sale1.value == 3){
            first.value = last.value
        }
        else if(sale1.value == 4){
            first.value = last.value*1000
        }
        else if(sale1.value == 5){
            first.value = last.value*1e+6
        }
        else if(sale1.value == 6){
            first.value = last.value*304.8
        }
        else if(sale1.value == 7){
            first.value = last.value*914.4
        }
        else if(sale1.value == 8){
            first.value = last.value*1.609e+6
        }
    }
    else if(sale.value == 4){
        if (sale1.value == 1){
            first.value = last.value/100
        }
        else if(sale1.value == 2){
            first.value = last.value/39.3701
        }  
        else if(sale1.value == 3){
            first.value = last.value/1000
        }
        else if(sale1.value == 4){
            first.value = last.value
        }
        else if(sale1.value == 5){
            first.value = last.value*1000
        }
        else if(sale1.value == 6){
            first.value = last.value/3.281
        }
        else if(sale1.value == 7){
            first.value = last.value/1.094
        }
        else if(sale1.value == 8){
            first.value = last.value* 1609.34
        }
    }
    else if(sale.value == 5){
        if (sale1.value == 1){
            first.value = last.value/100000
        }
        else if(sale1.value == 2){
            first.value = last.value/39370
        }  
        else if(sale1.value == 3){
            first.value = last.value/1e+6
        }
        else if(sale1.value == 4){
            first.value = last.value/1000
        }
        else if(sale1.value == 5){
            first.value = last.value
        }
        else if(sale1.value == 6){
            first.value = last.value/3281
        }
        else if(sale1.value == 7){
            first.value = last.value/1904
        }
        else if(sale1.value == 8){
            first.value = last.value* 1.60934
        }
    }
    else if(sale.value == 6){
        if (sale1.value == 1){
            first.value = last.value/30.48
        }
        else if(sale1.value == 2){
            first.value = last.value/12
        }  
        else if(sale1.value == 3){
            first.value = last.value/304.8

        }
        else if(sale1.value == 4){
            first.value = last.value*3.281
        }
        else if(sale1.value == 5){
            first.value = last.value*3281
        }
        else if(sale1.value == 6){
            first.value = last.value
        }
        else if(sale1.value == 7){
            first.value = last.value*3
        }
        else if(sale1.value == 8){
            first.value = last.value* 5280
        }
    }
    else if(sale.value == 7){
        if (sale1.value == 1){
            first.value = last.value/91.44
        }
        else if(sale1.value == 2){
            first.value = last.value/36
        }  
        else if(sale1.value == 3){
            first.value = last.value/914.4

        }
        else if(sale1.value == 4){
            first.value = last.value*1.094
        }
        else if(sale1.value == 5){
            first.value = last.value*1094
        }
        else if(sale1.value == 6){
            first.value = last.value/3
        }
        else if(sale1.value == 7){
            first.value = last.value
        } 
        else if(sale1.value == 8){
            first.value = last.value* 1760
        }
    }
    else if(sale.value == 8){
        if (sale1.value == 1){
            first.value = last.value/160900
        }
        else if(sale1.value == 2){
            first.value = last.value/63360

        }  
        else if(sale1.value == 3){
            first.value = last.value/1.609e+6
        }
        else if(sale1.value == 4){
            first.value = last.value/1609   
        }
        else if(sale1.value == 5){
            first.value = last.value/1.609
        }
        else if(sale1.value == 6){
            first.value = last.value/5280
        }
        else if(sale1.value == 7){
            first.value = last.value/1760
        } 
        else if(sale1.value == 8){
            first.value = last.value
        }
    }
}
const gun = ()=>{
    if (sale1.value == 1){
        if (sale.value == 1){
            last.value = first.value
        }
        else if(sale.value == 2){
            last.value = first.value*2.54
        }
        else if(sale.value == 3){
            last.value = first.value/10
        }
        else if(sale.value == 4){
            last.value = first.value*100
        }
        else if(sale.value == 5){
            last.value = first.value*100000
        }
        else if(sale.value == 6){
            last.value = first.value*30.48
        }
        else if(sale.value == 7){
            last.value = first.value*91.44
        }
        else if(sale.value == 8){
            last.value = first.value*160900
        }

    }
    else if(sale1.value == 2){
        if (sale.value == 1){
            last.value = first.value/2.54
        }
        else if(sale.value == 2){
            last.value = first.value
        }
        else if(sale.value == 3){
            last.value = first.value/25.4
        }
        else if(sale.value == 4){
            last.value = first.value*39.3701
        }
        else if(sale.value == 5){
            last.value = first.value*39370
        }
        else if(sale.value == 6){
            last.value = first.value*12
        }
        else if(sale.value == 7){
            last.value = first.value*36
        }
        else if(sale.value == 8){
            last.value = first.value*63360
        }
    }
    else if(sale1.value == 3){
        if (sale.value == 1){
            last.value = first.value*10
        }
        else if(sale.value == 2){
            last.value = first.value/25.4
        }  
        else if(sale.value == 3){
            last.value = first.value
        }
        else if(sale.value == 4){
            last.value = first.value*1000
        }
        else if(sale.value == 5){
            last.value = first.value*1e+6
        }
        else if(sale.value == 6){
            last.value = first.value*304.8
        }
        else if(sale.value == 7){
            last.value = first.value*914.4
        }
        else if(sale.value == 8){
            last.value = first.value* 1.609e+6
        }
    }
    else if(sale1.value == 4){
        if (sale.value == 1){
            last.value = first.value/100
        }
        else if(sale.value == 2){
            last.value = first.value/39.3701
        }  
        else if(sale.value == 3){
            last.value = first.value/1000
        }
        else if(sale.value == 4){
            last.value = first.value
        }
        else if(sale.value == 5){
            last.value = first.value*1000
        }
        else if(sale1.value == 6){
            last.value = first.value/3.281
        }
        else if(sale.value == 7){
            last.value = first.value/1.094
        }
        else if(sale.value == 8){
            last.value = first.value* 1609.34
        }
    }
    else if(sale1.value == 5){
        if (sale.value == 1){
            last.value = first.value/100000
        }
        else if(sale.value == 2){
            last.value = first.value/39370
        }  
        else if(sale.value == 3){
            last.value = first.value/1e+6
        }
        else if(sale.value == 4){
            last.value = first.value/1000
        }
        else if(sale.value == 5){
            last.value = first.value
        }
        else if(sale.value == 6){
            last.value = first.value/3281
        }
        else if(sale.value == 7){
            last.value = first.value/1094
        }
        else if(sale.value == 8){
            last.value = first.value* 1.60934
        }
    }
    else if(sale1.value == 6){
        if (sale.value == 1){
            last.value = first.value/30.48
        }
        else if(sale.value == 2){
            last.value = first.value/12
        }  
        else if(sale.value == 3){
            last.value = first.value/304.8

        }
        else if(sale.value == 4){
            last.value = first.value*3.281
        }
        else if(sale.value == 5){
            last.value = first.value*3280.84
        }
        else if(sale.value == 6){
            last.value = first.value
        }
        else if(sale.value == 7){
            last.value = first.value*3
        }
        else if(sale.value == 8){
            last.value = first.value* 5280
        }
    }
    else if(sale1.value == 7){
        if (sale.value == 1){
            last.value = first.value/91.44
        }
        else if(sale.value == 2){
            last.value = first.value/36
        }  
        else if(sale.value == 3){
            last.value = first.value/914.4

        }
        else if(sale.value == 4){
            last.value = first.value*1.094
        }
        else if(sale.value == 5){
            last.value = first.value/1094
        }
        else if(sale.value == 6){
            last.value = first.value
        }
        else if(sale.value == 7){
            last.value = first.value
        } 
        else if(sale.value == 8){
            last.value = first.value* 1760
        }
    }
    else if(sale1.value == 8){
        if (sale.value == 1){
            last.value = first.value/160900
        }
        else if(sale.value == 2){
            last.value = first.value/63360

        }  
        else if(sale.value == 3){
            last.value = first.value*6.2137e-7

        }
        else if(sale.value == 4){
            last.value = first.value/1609   
        }
        else if(sale.value == 5){
            last.value = first.value/1.609
        }
        else if(sale.value == 6){
            last.value = first.value/5280
        }
        else if(sale.value == 7){
            last.value = first.value/1760
        } 
        else if(sale.value == 8){
            last.value = first.value
        }
    }
}

// selecting the elements
var date = document.getElementById('date');
var calculate = document.getElementById('calculate');
var result = document.querySelector('.result');

// set maximum date to today
date.max = new Date().toISOString().split('T')[0];

function calculateAge() {
  var today = new Date();
  var birthDate = new Date(date.value);

  // Calculate years
  var years;
  if (today.getMonth() > birthDate.getMonth() || (today.getMonth() == birthDate.getMonth() && today.getDate() >= birthDate.getDate())) {
    years = today.getFullYear() - birthDate.getFullYear();
  }
  else {
    years = today.getFullYear() - birthDate.getFullYear() - 1;
  }

  // Calculate months
  var months;
  if (today.getDate() >= birthDate.getDate()) {
    months = today.getMonth() - birthDate.getMonth();
  }
  else if (today.getDate() < birthDate.getDate()) {
    months = today.getMonth() - birthDate.getMonth() - 1;
  }
  // make month positive
  months = months < 0 ? months + 12 : months;

  // Calculate days
  var days;
  // days of months in a year
  var monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (today.getDate() >= birthDate.getDate()) {
    days = today.getDate() - birthDate.getDate();
  } else {
    days = today.getDate() - birthDate.getDate() + monthDays[birthDate.getMonth()];
  }

  // Display result
  result.innerHTML = `<p class="birthdate">You were born on ${birthDate.toDateString()}.</p>`;
  result.innerHTML += `<p class="age">You are ${years} years, ${months} months and ${days} days old.</p>`;
  if (months == 0 && days == 0) {
    result.innerHTML += `<p class="wishing">Happy Birthday!🎂🎈🎈</p>`;
  }
}
calculate.addEventListener('click', calculateAge);

// run calculate on enter key
document.addEventListener('keypress', (e) => {
  if (e.keyCode == 13) {
    calculate.click();
  }
});
// onload focus on date input
date.focus();