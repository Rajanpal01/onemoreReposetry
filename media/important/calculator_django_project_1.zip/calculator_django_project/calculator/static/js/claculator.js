var B = []
var form_value = document.getElementById('form')
const cost = (event)=>{
    B.push(event)
    form_value.value = B.join('')
}

const equal = () =>{
    let vast = eval(form_value.value)
    form_value.value = vast
    let hook = vast.toString().split('')
    B  = hook
}

const escap = () =>{
    B = []
    form_value.value = B
}

const last_escape_only = () =>{
    B.pop()
    form_value.value = B.join('')
}
function fillData(){
    document.getElementById('second_data').value = B.join('')
}
function show_message(){
    var mkk = document.getElementById('second_data')
    var clock = document.querySelector('.after_click_page1')
    let Alter_show = document.getElementById('Alter_Alter')
    if ( clock.style.display == 'none'){
        clock.style.display = 'block'
        mkk.value = B.join('')
        Alter_show.style.display = 'block'
        
    }
    else{
        clock.style.display = 'none'
       
    }
   
}
