function n_calc(){
   document.getElementById('one_right').style.display='block'
   document.getElementById('one_left').style.display='none' 
   document.getElementById('Con_calc').style.background = 'rgb(164, 223, 247)'
   document.getElementById('calculator_calc').style.background='rgba(64, 62, 62, 0.404)'
}
function l_calc(){
    document.getElementById('one_left').style.display='block' 
    document.getElementById('one_right').style.display='none'
    document.getElementById('calculator_calc').style.background='rgb(164, 223, 247)'
    document.getElementById('Con_calc').style.background = 'rgba(64, 62, 62, 0.404)'
 }

function first_button(){
    var jack  = document.getElementById('one_sote')
    var block = document.getElementById('form')
    jack.classList.toggle('opacity')  
    (block.disabled == true) ? block.disabled = false:block.disabled = true;
    (block.disabled == true) ? console.log('first is true'):console.log('last is true');
}
function side_page_open(event){
    var block = document.getElementsByClassName('after_click_page')
    if (event == 'first_side'){
        block[0].classList.toggle('display_style')
    }
    else if(event == 'secound_side'){
        block[1].classList.toggle('display_style')
    }
    else if(event == 'third_side'){
        block[2].classList.toggle('display_style')
    }
    else if(event == 'four_side'){
        block[3].classList.toggle('display_style')
    }
}
var Success = document.getElementById('Alter_Alter')
document.getElementById('but_al').addEventListener('click',()=>{
    Success.style.display = 'block'
    setTimeout(()=>{
            Success.style.display = 'none'
    },1000)
})


let i = 0
function switch_click(){
    let A = document.querySelector('.calc_area')
    let Form = document.querySelector('.form')
    let list = document.querySelectorAll('.number')
    if ( i == 0){
        A.style.backgroundColor='rgb(99,115,159)'
        Form.style.backgroundColor ='#cbd9e7'
        Form.style.color ='#fff'
        for (let m = 0; m < list.length; m++) {
            list[m].style.backgroundColor = "white";
            list[m].style.color = 'black'
        }       
        i = 1
    }
    else{
        A.style.backgroundColor='rgb(164, 223, 247)'
        Form.style.backgroundColor ='azure'
        Form.style.color ='black'
        for (let i = 0; i < list.length; i++) {
            list[i].style.backgroundColor = "rgb(142,135,138)";
            list[i].style.color = 'white'
        }     
        
        i = 0
    }    
}

/*window.onclick = function(event){
    if(!event.target.matches('#first_side')){
        var A = document.getElementsByClassName('after_click_page')
        if(A[0].classList.contains('display_style')){
            A[0].classList.remove('display_style');
        }
    }
     if(!event.target.matches('#save_page_toggle')){
        var A = document.querySelector('.after_click_page1')
        if(A.classList.contains('display_style')){
            A.classList.remove('display_style');
        }
    }
    if(!event.target.matches('#secound_side')){
        var A = document.getElementsByClassName('after_click_page')
        if(A[1].classList.contains('display_style')){
            A[1].classList.remove('display_style');
        }
    }
    if(!event.target.matches('#third_side')){
        var A = document.getElementsByClassName('after_click_page')
        if(A[2].classList.contains('display_style')){
            A[2].classList.remove('display_style');
        }
    }
    if(!event.target.matches('#four_side')){
        var A = document.getElementsByClassName('after_click_page')
        if(A[3].classList.contains('display_style')){
            A[3].classList.remove('display_style');
        }
    }
}*/
