from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import Details
# Create your views here.

def index(request):
    if request.method == "POST":
        first = request.POST.get('motive_area')
        middle = request.POST.get('main_course')
        last = request.POST.get('last_area')
        ouput_value = Details(motive=first, main_are=middle, text_are=last)
        ouput_value.save()
        return HttpResponseRedirect('/')
    return render(request, 'index.html')

def home(request):
    data = Details.objects.all()
    return render(request, 'show_saved.html',{'data':data})


