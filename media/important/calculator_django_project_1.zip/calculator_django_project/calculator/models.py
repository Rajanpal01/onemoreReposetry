from django.db import models
from datetime import *

# Create your models here.
class Details(models.Model):
    motive = models.CharField(max_length=30, null=True)
    main_are = models.CharField(max_length=30, null=False)
    text_are = models.CharField(max_length=60, null=True)
    time = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.motive
